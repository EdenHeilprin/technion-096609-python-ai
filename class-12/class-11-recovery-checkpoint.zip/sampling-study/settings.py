"""Development settings for the private Classes 11–12 reference build."""

from os import environ


SESSION_CONFIGS = [
    dict(
        name="sampling_decisions",
        display_name="Sampling decisions — random condition",
        num_demo_participants=2,
        app_sequence=["sampling_task"],
    ),
    dict(
        name="sampling_decisions_persistent",
        display_name="Sampling decisions — persistent feedback",
        num_demo_participants=1,
        app_sequence=["sampling_task"],
        forced_condition="persistent",
    ),
    dict(
        name="sampling_decisions_transient",
        display_name="Sampling decisions — transient feedback",
        num_demo_participants=1,
        app_sequence=["sampling_task"],
        forced_condition="transient",
    ),
]

SESSION_CONFIG_DEFAULTS = dict(
    real_world_currency_per_point=1.0,
    participation_fee=0.0,
    doc="",
)

PARTICIPANT_FIELDS = ["condition", "trial_order"]
SESSION_FIELDS = []

LANGUAGE_CODE = "en"
REAL_WORLD_CURRENCY_CODE = "ILS"
USE_POINTS = False

ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = environ.get("OTREE_ADMIN_PASSWORD")
DEMO_PAGE_INTRO_HTML = """A local teaching build for Classes 11–12."""
SECRET_KEY = environ.get("OTREE_SECRET_KEY", "local-development-only")
