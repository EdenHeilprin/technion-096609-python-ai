"""A four-trial oTree sampling experiment with two feedback conditions.

Participants sample outcomes from two options before choosing one. The
between-participant condition determines whether earlier samples remain
visible. Every round saves the condition, presented lotteries, display order,
sample sequences, choice, and timing fields needed for a trial-level export.
"""

import csv
import json
import random
from pathlib import Path

from otree.api import *


doc = """
A minimal sampling-based decision experiment used in Classes 11 and 12.
"""


class C(BaseConstants):
    NAME_IN_URL = "sampling_task"
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 4
    SAMPLES_PER_OPTION = 5
    CONDITIONS = ["persistent", "transient"]

    ADMIN_VIEW_FIELDS = {
        "player": [
            "condition",
            "trial_id",
            "left_option_id",
            "right_option_id",
            "choice",
        ]
    }


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    condition = models.StringField()
    trial_id = models.StringField()

    left_option_id = models.StringField()
    right_option_id = models.StringField()

    option_a_low = models.IntegerField()
    option_a_high = models.IntegerField()
    option_a_high_probability = models.FloatField()
    option_b_low = models.IntegerField()
    option_b_high = models.IntegerField()
    option_b_high_probability = models.FloatField()

    sample_sequence_a = models.LongStringField()
    sample_sequence_b = models.LongStringField()
    sample_count_a = models.IntegerField(initial=0)
    sample_count_b = models.IntegerField(initial=0)

    selected_side = models.StringField(blank=True)
    choice = models.StringField(blank=True)
    decision_rt_ms = models.IntegerField(blank=True)
    trial_rt_ms = models.IntegerField(blank=True)


def load_stimuli():
    """Load and validate the four lottery trials used by the experiment."""

    stimuli_path = Path(__file__).parent.parent / "stimuli.csv"
    with stimuli_path.open(encoding="utf-8", newline="") as csv_file:
        rows = list(csv.DictReader(csv_file))

    required_columns = {
        "trial_id",
        "option_a_low",
        "option_a_high",
        "option_a_high_probability",
        "option_b_low",
        "option_b_high",
        "option_b_high_probability",
    }
    if not rows or set(rows[0]) != required_columns:
        raise ValueError("stimuli.csv does not match the required columns")
    if len(rows) != C.NUM_ROUNDS:
        raise ValueError(f"stimuli.csv must contain exactly {C.NUM_ROUNDS} trials")

    parsed_rows = []
    seen_ids = set()
    for row in rows:
        trial_id = row["trial_id"].strip()
        if not trial_id or trial_id in seen_ids:
            raise ValueError("Every trial_id must be non-empty and unique")
        seen_ids.add(trial_id)

        parsed = {"trial_id": trial_id}
        for option in ("a", "b"):
            low = int(row[f"option_{option}_low"])
            high = int(row[f"option_{option}_high"])
            probability = float(row[f"option_{option}_high_probability"])
            if low >= high:
                raise ValueError(f"{trial_id}: low outcome must be below high outcome")
            if not 0 < probability < 1:
                raise ValueError(f"{trial_id}: probabilities must lie between 0 and 1")
            parsed[f"option_{option}_low"] = low
            parsed[f"option_{option}_high"] = high
            parsed[f"option_{option}_high_probability"] = probability
        parsed_rows.append(parsed)

    return parsed_rows


STIMULI = load_stimuli()
STIMULI_BY_ID = {row["trial_id"]: row for row in STIMULI}


def draw_sample_sequence(low, high, high_probability):
    """Draw the outcomes that one participant can reveal from one option."""

    return [
        high if random.random() < high_probability else low
        for _ in range(C.SAMPLES_PER_OPTION)
    ]


def creating_session(subsession):
    """Assign one condition and randomized trial order, then prepare each round."""

    for player in subsession.get_players():
        participant = player.participant

        if subsession.round_number == 1:
            participant.condition = player.session.config.get(
                "forced_condition", random.choice(C.CONDITIONS)
            )
            trial_order = [row["trial_id"] for row in STIMULI]
            random.shuffle(trial_order)
            participant.trial_order = trial_order

        # Copy the participant-level assignment into every trial row so the
        # exported dataset is self-contained.
        player.condition = participant.condition
        player.trial_id = participant.trial_order[subsession.round_number - 1]

        stimulus = STIMULI_BY_ID[player.trial_id]
        for field_name, value in stimulus.items():
            if field_name != "trial_id":
                setattr(player, field_name, value)

        if random.choice([True, False]):
            player.left_option_id = "A"
            player.right_option_id = "B"
        else:
            player.left_option_id = "B"
            player.right_option_id = "A"

        player.sample_sequence_a = json.dumps(
            draw_sample_sequence(
                player.option_a_low,
                player.option_a_high,
                player.option_a_high_probability,
            )
        )
        player.sample_sequence_b = json.dumps(
            draw_sample_sequence(
                player.option_b_low,
                player.option_b_high,
                player.option_b_high_probability,
            )
        )


class Instructions(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == 1


class Decision(Page):
    form_model = "player"
    form_fields = [
        "sample_count_a",
        "sample_count_b",
        "selected_side",
        "choice",
        "decision_rt_ms",
        "trial_rt_ms",
    ]
    @staticmethod
    def vars_for_template(player):
        option_values = {
            "A": dict(
                low=player.option_a_low,
                high=player.option_a_high,
                probability=player.option_a_high_probability,
            ),
            "B": dict(
                low=player.option_b_low,
                high=player.option_b_high,
                probability=player.option_b_high_probability,
            ),
        }
        return dict(
            left_option=option_values[player.left_option_id],
            right_option=option_values[player.right_option_id],
        )

    @staticmethod
    def js_vars(player):
        return dict(
            condition=player.condition,
            samples_per_option=C.SAMPLES_PER_OPTION,
            sample_sequence_a=json.loads(player.sample_sequence_a),
            sample_sequence_b=json.loads(player.sample_sequence_b),
            left_option_id=player.left_option_id,
            right_option_id=player.right_option_id,
        )

    @staticmethod
    def error_message(player, values):
        if values["sample_count_a"] != C.SAMPLES_PER_OPTION:
            return f"Reveal exactly {C.SAMPLES_PER_OPTION} samples from Option A."
        if values["sample_count_b"] != C.SAMPLES_PER_OPTION:
            return f"Reveal exactly {C.SAMPLES_PER_OPTION} samples from Option B."

        selected_side = values["selected_side"]
        expected_choice = {
            "left": player.left_option_id,
            "right": player.right_option_id,
        }.get(selected_side)
        if values["choice"] != expected_choice:
            return "The stored choice does not match the selected side."

class Completion(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS

page_sequence = [Instructions, Decision, Completion]
