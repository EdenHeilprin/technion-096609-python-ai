# Class 11 recovery checkpoint

This tested project contains the experiment at the end of Class 11, after Milestones 1–3. It is a fallback for a student whose agent-built project cannot be repaired in time for Class 12.

It contains four CSV-defined trials, stable participant-level condition assignment, randomized trial order and left-right mapping, five samples per option, persistent and transient feedback, choice, and timing fields.

It deliberately does not contain the Class 12 work: timeout behavior, bots, a custom export, an independent export validator, or the final project README.

Run locally with:

```text
otree devserver
```
