# Class 9 — Codex, oTree, and GitHub Setup

In Class 8, you saw how Codex could build an experiment. Today, you will run that experiment on your own laptop, find its saved responses, and change its thank-you page—first by hand, then with Codex.

You will also install Git and connect your GitHub account, ready to contribute your own lesson in Class 10.

You need the Python 3.13 and VS Code setup from [Class 0](https://github.com/EdenHeilprin/technion-096609-python-ai/tree/main/class-00-setup). This lesson uses **oTree 6.0.15** in a separate project environment. Keep any other Python installations you already use.

## 1. Download and open the project

**[Download Class 9 files](https://github.com/EdenHeilprin/technion-096609-python-ai/raw/refs/heads/main/class-09/class-09-files.zip)**

Extract the ZIP: double-click it on Mac, or right-click → **Extract All** on Windows. Move the extracted `class-09` folder into your course-work folder, next to your earlier classes. **Open VS Code**, choose **File → Open Folder**, and select this `class-09` folder. Trust the folder if VS Code asks, after checking that it came from this repository.

You should see `settings.py`, `requirements.txt`, and the `choice_task` folder directly in the Explorer. This is an already working experiment; you do not need to ask AI to build it again.

## 2. Install oTree and start the experiment

We will use **VS Code's terminal**: the panel where you type commands to run programs. Follow the guide for your computer from beginning to end. It takes you through opening that terminal, checking Python and your folder, installing oTree, and starting it:

- **[macOS setup](macos.md)**
- **[Windows setup](windows.md)**

The guide creates `.venv`: a folder containing this project's Python environment and installed packages. It also runs the supplied `check_setup.py` file, which prints **CLASS 9 SETUP PASSED** when the Python and oTree versions are correct.

The final command is `otree devserver`. It starts the **local server**: the program that displays the experiment's pages in your browser and saves your responses on your laptop. Downloading the files alone does not start it.

Return here when the terminal displays **Open your browser to http://localhost:8000/**. Leave that terminal open.

## 3. Complete a run and find your answers

After completing the setup guide, open **[http://localhost:8000](http://localhost:8000)** in your browser. This is oTree's **administrator page**, where you create a session before opening a participant's experiment.

1. Click **Sessions** in the top menu, then **Create new session**.
2. In the **Session Config** dropdown, select **Sure or gamble**. This is the name of our experiment.
3. In **Number of participants**, type **2**, then click **Create**. This creates two participant places, each with its own link. You will complete both yourself to check the two presentation orders; you do not need another person.
4. Open the session's **Links** tab. Open the first **single-use participant link** in a new browser tab, keeping the administrator tab open. Complete consent and details with a made-up ID such as `practice-a`.
5. Complete all **seven decisions**. Note your first and last prize and at least one choice. Keep the thank-you tab open; you will use it again shortly.
6. Return to the administrator tab and open the second participant link with a different made-up ID, `practice-b`. Complete all seven decisions again. The prizes should now appear in the opposite order.

Each participant sees the same prizes: **2, 8, 14, 20, 26, 32, 38**, either ascending or descending. The sure option stays at **10 points**. A stored choice is `sure` or `gamble`.

**Note:** `localhost` means **this computer**. These pages are running on your laptop, not on a public website, so sending this address to someone else will not let them join your experiment.

## 4. Find your saved responses

1. Return to the administrator tab and click **Data** in the top menu.
2. Scroll to **Per-app data**. In the **choice_task** row, click **CSV**.
3. Create an `exports` folder inside `class-09` and save the downloaded file there. Open it in Excel or RStudio.
4. Find `participant.code`, `subsession.round_number`, `player.prize`, and `player.choice`. Each row represents **one participant's decision in one round**. Your two completed runs therefore contribute **14 rows**. If you created additional sessions, the file will include their rows too; `session.code` identifies each session.
5. Match the saved prizes and choices to the responses you entered. Find the ascending/descending assignment in `player.condition` on each participant's **round 1** row.

The **All apps (wide format)** export is another layout of the data: one row per participant, with separate columns for every round. Here, we use the per-app file because it is easier to inspect one decision at a time.

## 5. Change the thank-you message yourself

Return to **VS Code**, with `class-09` still open.

1. In the Explorer on the left, expand `choice_task`. Which file looks like it controls the final page? Open **ThankYou.html**.
2. Find `Your seven decisions have been recorded.` Change only that text to **Your seven decisions have been saved.** Keep the surrounding `<p>` and `</p>` tags; they mark a paragraph.
3. Save the file with **Cmd+S** on Mac or **Ctrl+S** on Windows.
4. Return to the completed participant’s thank-you tab and **refresh** it. Does it show your new sentence? Keep oTree running; HTML text and styling changes appear on refresh.

A small wording change is often quicker to make directly. Next, you will ask Codex to redesign the completion page.

## 6. Install Codex and open this folder

1. Use OpenAI's **[official desktop download and setup page](https://learn.chatgpt.com/docs/quickstart)**. Install the app for your operating system and sign in with your **ChatGPT account**. The current desktop app includes Codex; select **Codex** in its ChatGPT/Codex selector. If you already have the Codex desktop app, use it.
2. Add/open a **local project** and select this exact `class-09` folder. Keep the work on your computer, not in a cloud environment. On Windows, follow the app's native setup prompts; this lesson does not require WSL.
3. Keep the normal project-limited permissions. On Windows, select **Ask for approval** below the composer. Review requests for access outside the project or for network access; do not select unrestricted/full access just to complete this lesson.

On Mac, check **Apple menu → About This Mac**: the [current Mac desktop download](https://learn.chatgpt.com/docs/app) is labeled **Apple Silicon**. If you have an Intel Mac or the installer reports an unsupported operating system, complete the local oTree steps and manual edit, then contact the instructor for a compatible Codex route.

The [Free plan currently includes limited Codex access](https://learn.chatgpt.com/docs/pricing), subject to availability and usage limits. No paid subscription or API key is required for this activity. If access is unavailable or you reach a limit, use the manual alternative below and try the Codex step when access returns.

## 7. Redesign the completion page with Codex

In your Class 9 Codex project, send this prompt:

```text
Redesign choice_task/ThankYou.html as a clear, welcoming completion page for
laptop screens. Change “Your seven decisions have been recorded.” to “Your
seven decisions have been saved.” if needed.

Use a large green checkmark, a prominent thank-you heading, and a centered
pale-green panel with dark-green text and generous spacing. Make “saved” bold.
Keep the message telling participants they may close the tab.

Edit only this file, so the design change affects only the final page. Keep
the experiment logic and saved responses unchanged. Do not access exports or
the database.

Add brief comments explaining the new styling. Show me what changed and
explain it in simple terms.
```

Open `ThankYou.html` in VS Code and inspect the changes. Find the confirmation sentence and the code responsible for the checkmark, colors, and spacing.

Save `ThankYou.html` and refresh the thank-you tab while oTree is still running. Compare it with the original page. Does it clearly confirm that the decisions have been **saved** and that the participant can close the tab?

<details>
<summary>Manual alternative — one possible design</summary>

Replace the contents of `choice_task/ThankYou.html` with this code and save:

```html
{{ block title }}Thank you!{{ endblock }}
{{ block styles }}
<link rel="stylesheet" href="{{ static 'choice_task/design.css' }}">
<style>
/* These styles appear only on the thank-you page. */
.otree-title { text-align: center; color: #166534; }
.completion-card {
    max-width: 640px;
    margin: 0 auto;
    padding: 36px;
    text-align: center;
    background: #eef7ef;
    color: #166534;
    border-radius: 18px;
}
/* Make the checkmark the page's main visual signal. */
.completion-check { font-size: 64px; margin-bottom: 20px; }
</style>
{{ endblock }}
{{ block content }}
<section class="completion-card">
    <!-- The text also confirms completion; the symbol is decorative. -->
    <div class="completion-check" aria-hidden="true">✓</div>
    <p>Your seven decisions have been <strong>saved</strong>.</p>
    <p>Thank you for participating. You may now close this tab.</p>
</section>
{{ endblock }}
```

The HTML groups the completion message; the CSS inside `<style>` controls its appearance. These styles are included only on this page. Refresh the thank-you tab while oTree is still running.

</details>

## 8. Set up Git and GitHub

So far, you have used GitHub to download the course. In Class 10, you will use it to propose a lesson of your own. We will prepare the tools together now.

Follow **[Git and GitHub setup](git-setup.md)**. It covers account sign-in, installing Git and GitHub CLI on Mac or Windows, and finding the email address Git will use to label your work. The guide starts by stopping oTree so the terminal is ready for new commands.

## A quick map of the code

| File | What it controls |
| --- | --- |
| `settings.py` | The session listed on the administrator page |
| `choice_task/__init__.py` | Prizes, order assignment, saved responses, and page sequence |
| `choice_task/*.html` | The words and forms shown to participants |
| `_static/choice_task/design.css` | Colors, spacing, and layout |
| `requirements.txt` | The required oTree version |

In `__init__.py`, find `PRIZES` and `prize_for_round`. Recognize the list, function, parameter, `if`, and `return`? Those are the same Python tools you already know. The classes and oTree-specific methods connect that logic to pages and saved responses.

## Before you finish

- [ ] I can start and stop this experiment from VS Code's terminal.
- [ ] I completed both presentation orders and found my saved decisions in the per-app CSV.
- [ ] I changed the thank-you text by hand and saw the new wording in the browser.
- [ ] I compared the redesigned thank-you page with the original and checked its completion message.
- [ ] Git and GitHub CLI are installed, and `gh auth status` shows my own account.
- [ ] I have my GitHub username and noreply address ready for Class 10.

To stop oTree, first close **all browser tabs showing this local experiment**, including the administrator tab. Then press **Control+C** in its VS Code terminal and wait for the command prompt. This lets oTree finish saving your responses. To start again, run `otree devserver` in the same terminal and reopen `http://localhost:8000`. For help with a step, see [Troubleshooting](TROUBLESHOOTING.md).

## Companion tutorials

**[HTML in 100 Seconds — Fireship](https://www.youtube.com/watch?v=ok-plXXHlWw).** Watch the full short video for an overview of how tags structure a web page. Connect it to the paragraph and text formatting on the thank-you page. Pause or slow playback when needed.

**Before Class 10, strongly recommended: [A brief introduction to Git for beginners — GitHub](https://www.youtube.com/watch?v=r8jQ9hVA2qs).** Watch **00:00–03:06** for version control, repositories, commits, and branches, then **08:29 to the end** for Git versus GitHub. These ideas explain how a change on your laptop eventually reaches the course online. Use our setup guide for installation; focus here on recognizing what each tool does. After watching, can you explain why saving an edited file does not update GitHub?

---

[Back to the course](https://github.com/EdenHeilprin/technion-096609-python-ai)
